/* assets.h - municipal asset operations and storage */
#ifndef ASSETS_H
#define ASSETS_H

#include <stddef.h>
#include "records.h"

void   addAsset(void);
void   displayAssets(void);
double calculateAssetTotal(void);

size_t       assetCount(void);
const Asset *getAsset(size_t index);

int saveAssetsText(void);
int loadAssetsText(void);

#endif
