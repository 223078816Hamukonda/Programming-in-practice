#!/bin/sh
# Three test runs. Run from the project folder:  sh tests/run_tests.sh
# Output of each run is saved in tests/outputN.txt
cd "$(dirname "$0")/.." || exit 1
rm -f data/*.txt data/*.dat data/*.bak data/*.tmp

echo "== Test 1: enter records, save (text + binary), export report, exit"
printf '%s\n' \
  1 1001 "Maria Shikongo" 18500.50 "" \
  1 1002 "Simon Peters" 17200 "" \
  1 1001 "" \
  4 501 "Windhoek Stationery" 061123456 "" \
  6 9001 "Fire Truck" 1250000 "" \
  8 7001 Water 500000 125000.75 "" \
  10 "" 12 "" 14 "" 11 "" 0 > tests/input1.txt
./mfms < tests/input1.txt > tests/output1.txt
echo "-- data files after run 1:"; ls -l data | grep -v gitkeep
echo "-- data/employees.txt:"; cat data/employees.txt

echo; echo "== Test 2: NEW process, memory empty -> load text, list, search, backup"
printf '%s\n' 2 "" 13 "" 2 "" 3 simon "" 9 "" 16 "" 0 > tests/input2.txt
./mfms < tests/input2.txt > tests/output2.txt
grep -E "No employees|Loaded|ID: 100|Backup|Dept" tests/output2.txt

echo; echo "== Test 3: binary load, missing file, malformed + duplicate lines"
rm -f data/assets.txt
printf '%s\n' \
  '2001|Good Record|100.00' \
  'this line is garbage' \
  '2001|Duplicate Id|5.00' \
  '2002|Negative|-5' \
  '2003|Name Only' \
  '' \
  '2004|Last Good|42.50' > data/employees.txt
printf '%s\n' 15 "" 2 "" 13 "" 2 "" 7 "" 0 > tests/input3.txt
./mfms < tests/input3.txt > tests/output3.txt
grep -E "Binary load|ID: |No saved|Loaded|Warning" tests/output3.txt

echo; echo "== Test 4: data directory missing -> save must fail safely"
mv data data_hidden
printf '%s\n' 1 1 Test 1 "" 12 "" 0 | ./mfms 2>&1 | grep -E "data/|Saved"
mv data_hidden data
