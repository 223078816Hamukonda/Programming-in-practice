/* utilities.c */
#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "config.h"
#include "utilities.h"

static void inputClosed(void)
{
    printf("\nInput closed. Exiting.\n");
    exit(0);
}

int readLine(const char *prompt, char *buf, size_t size)
{
    size_t len;
    int ch;

    if (prompt != NULL) {
        printf("%s", prompt);
        fflush(stdout);
    }
    if (fgets(buf, (int)size, stdin) == NULL) {
        return 0;
    }
    len = strlen(buf);
    if (len > 0 && buf[len - 1] == '\n') {
        buf[len - 1] = '\0';
    } else {
        /* line was longer than the buffer: discard the rest of it */
        while ((ch = getchar()) != '\n' && ch != EOF) {
        }
    }
    return 1;
}

int readInt(const char *prompt, int min, int max)
{
    char line[LINE_LEN];
    char *end;
    long value;

    for (;;) {
        if (!readLine(prompt, line, sizeof line)) {
            inputClosed();
        }
        errno = 0;
        value = strtol(line, &end, 10);
        if (end != line && *end == '\0' && errno == 0 &&
            value >= min && value <= max) {
            return (int)value;
        }
        printf("  Please enter a whole number from %d to %d.\n", min, max);
    }
}

double readDouble(const char *prompt, double min)
{
    char line[LINE_LEN];
    char *end;
    double value;

    for (;;) {
        if (!readLine(prompt, line, sizeof line)) {
            inputClosed();
        }
        errno = 0;
        value = strtod(line, &end);
        if (end != line && *end == '\0' && errno == 0 && value >= min) {
            return value;
        }
        printf("  Please enter a number that is at least %.2f.\n", min);
    }
}

void readText(const char *prompt, char *buf, size_t size)
{
    for (;;) {
        if (!readLine(prompt, buf, size)) {
            inputClosed();
        }
        if (buf[0] == '\0') {
            printf("  This field cannot be empty.\n");
        } else if (strchr(buf, '|') != NULL) {
            printf("  The '|' character is used as the file separator; please avoid it.\n");
        } else {
            return;
        }
    }
}

void pauseScreen(void)
{
    char dummy[LINE_LEN];
    printf("\nPress Enter to continue...");
    fflush(stdout);
    (void)readLine(NULL, dummy, sizeof dummy);
}

int containsIgnoreCase(const char *haystack, const char *needle)
{
    size_t i, j;
    size_t hl = strlen(haystack);
    size_t nl = strlen(needle);

    if (nl == 0) {
        return 1;
    }
    for (i = 0; i + nl <= hl; i++) {
        for (j = 0; j < nl; j++) {
            if (tolower((unsigned char)haystack[i + j]) !=
                tolower((unsigned char)needle[j])) {
                break;
            }
        }
        if (j == nl) {
            return 1;
        }
    }
    return 0;
}

int reportOpenFailure(const char *path)
{
    if (errno == ENOENT) {
        printf("  No saved file yet (%s) - nothing loaded.\n", path);
        return 0;
    }
    perror(path);
    return -1;
}

FILE *beginSafeWrite(const char *path, const char *mode, char *tmp, size_t tmpSize)
{
    FILE *fp;

    if (snprintf(tmp, tmpSize, "%s.tmp", path) >= (int)tmpSize) {
        fprintf(stderr, "Path too long: %s\n", path);
        return NULL;
    }
    fp = fopen(tmp, mode);
    if (fp == NULL) {
        perror(tmp);   /* usually: the data/ directory does not exist */
    }
    return fp;
}

int endSafeWrite(FILE *fp, const char *tmp, const char *path)
{
    int bad = ferror(fp);

    if (fclose(fp) != 0) {
        bad = 1;
    }
    if (bad) {
        fprintf(stderr, "Write error: %s was left unchanged.\n", path);
        remove(tmp);
        return -1;
    }
    if (rename(tmp, path) != 0) {
        /* Windows refuses to rename over an existing file; Linux/macOS do not. */
        if (errno == EEXIST) {
            remove(path);
            if (rename(tmp, path) == 0) {
                return 0;
            }
        }
        perror(path);
        return -1;
    }
    return 0;
}

int copyFile(const char *src, const char *dst)
{
    FILE *in = fopen(src, "rb");
    FILE *out;
    char buf[1024];
    size_t n;
    int ok = 1;

    if (in == NULL) {
        return (errno == ENOENT) ? 1 : -1;
    }
    out = fopen(dst, "wb");
    if (out == NULL) {
        perror(dst);
        fclose(in);
        return -1;
    }
    while ((n = fread(buf, 1, sizeof buf, in)) > 0) {
        if (fwrite(buf, 1, n, out) != n) {
            ok = 0;
            break;
        }
    }
    if (ferror(in)) {
        ok = 0;
    }
    if (fclose(out) != 0) {
        ok = 0;
    }
    fclose(in);
    return ok ? 0 : -1;
}
