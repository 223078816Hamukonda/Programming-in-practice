/* utilities.h - reusable input and file helper functions */
#ifndef UTILITIES_H
#define UTILITIES_H

#include <stddef.h>
#include <stdio.h>

/* ---- console input ---- */
int    readLine(const char *prompt, char *buf, size_t size);   /* 1 = ok, 0 = EOF */
int    readInt(const char *prompt, int min, int max);
double readDouble(const char *prompt, double min);
void   readText(const char *prompt, char *buf, size_t size);   /* non-empty, no '|' */
void   pauseScreen(void);
int    containsIgnoreCase(const char *haystack, const char *needle);

/* ---- file helpers ---- */
/* Report why fopen() failed. Returns 0 if the file simply does not exist yet,
   -1 for any other failure. Call immediately after a failed fopen(). */
int    reportOpenFailure(const char *path);

/* Safe saving: write to "<path>.tmp", then replace the real file only if every
   write succeeded. A failed save therefore never destroys the old data. */
FILE  *beginSafeWrite(const char *path, const char *mode, char *tmp, size_t tmpSize);
int    endSafeWrite(FILE *fp, const char *tmp, const char *path);

/* Copy a file. Returns 0 = copied, 1 = source missing, -1 = error. */
int    copyFile(const char *src, const char *dst);

#endif
