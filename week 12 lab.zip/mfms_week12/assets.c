/* assets.c - array: assets[], counter: assetTotal */
#include <stdio.h>
#include <string.h>
#include "assets.h"
#include "config.h"
#include "dates.h"
#include "records.h"
#include "utilities.h"

static Asset  assets[MAX_RECORDS];
static size_t assetTotal = 0;

static int findAssetIndex(int id)
{
    size_t i;
    for (i = 0; i < assetTotal; i++) {
        if (assets[i].id == id) {
            return (int)i;
        }
    }
    return -1;
}

size_t assetCount(void)
{
    return assetTotal;
}

const Asset *getAsset(size_t index)
{
    return (index < assetTotal) ? &assets[index] : NULL;
}

void addAsset(void)
{
    Asset a;

    if (assetTotal >= MAX_RECORDS) {
        printf("  Asset list is full (%d). Record refused.\n", MAX_RECORDS);
        return;
    }
    memset(&a, 0, sizeof a);
    a.id = readInt("  Asset ID (1-999999): ", 1, 999999);
    if (findAssetIndex(a.id) >= 0) {
        printf("  An asset with ID %d already exists.\n", a.id);
        return;
    }
    readText("  Description: ", a.description, sizeof a.description);
    a.value = readDouble("  Value: ", 0.0);
    readDate("Date acquired", &a.acquired);
    assets[assetTotal] = a;
    assetTotal++;
    printf("  Asset %d added.\n", a.id);
}

void displayAssets(void)
{
    size_t i;

    if (assetTotal == 0) {
        printf("  No assets in memory.\n");
        return;
    }
    printf("\n  %-6s %-34s %14s  %-10s\n", "ID", "Description", "Value", "Acquired");
    for (i = 0; i < assetTotal; i++) {
        printf("  %-6d %-34.34s %14.2f  %02d/%02d/%04d\n",
               assets[i].id, assets[i].description, assets[i].value,
               assets[i].acquired.day, assets[i].acquired.month,
               assets[i].acquired.year);
    }
    printf("  Assets: %lu   Total value: %.2f\n",
           (unsigned long)assetTotal, calculateAssetTotal());
}

double calculateAssetTotal(void)
{
    double sum = 0.0;
    size_t i;
    for (i = 0; i < assetTotal; i++) {
        sum += assets[i].value;
    }
    return sum;
}

/* One record per line:  id|description|value|day|month|year */

int saveAssetsText(void)
{
    char tmp[LINE_LEN];
    FILE *fp = beginSafeWrite(ASSETS_TXT, "w", tmp, sizeof tmp);
    size_t i;

    if (fp == NULL) {
        return -1;
    }
    for (i = 0; i < assetTotal; i++) {
        fprintf(fp, "%d|%s|%.2f|%d|%d|%d\n", assets[i].id, assets[i].description,
                assets[i].value, assets[i].acquired.day,
                assets[i].acquired.month, assets[i].acquired.year);
    }
    if (endSafeWrite(fp, tmp, ASSETS_TXT) != 0) {
        return -1;
    }
    return (int)assetTotal;
}

int loadAssetsText(void)
{
    FILE *fp = fopen(ASSETS_TXT, "r");
    char line[LINE_LEN];
    Asset a;
    int skipped = 0;

    if (fp == NULL) {
        return reportOpenFailure(ASSETS_TXT);
    }
    assetTotal = 0;
    while (fgets(line, sizeof line, fp) != NULL) {
        if (line[0] == '\n' || line[0] == '\r') {
            continue;
        }
        memset(&a, 0, sizeof a);
        if (sscanf(line, "%d|%39[^|]|%lf|%d|%d|%d", &a.id, a.description, &a.value,
                   &a.acquired.day, &a.acquired.month, &a.acquired.year) != 6 ||
            a.id < 1 || a.value < 0.0 || !isValidDate(&a.acquired) ||
            findAssetIndex(a.id) >= 0 || assetTotal >= MAX_RECORDS) {
            skipped++;
            continue;
        }
        assets[assetTotal++] = a;
    }
    if (ferror(fp)) {
        perror(ASSETS_TXT);
    }
    fclose(fp);
    if (skipped > 0) {
        printf("  Warning: %d malformed/duplicate line(s) skipped in %s.\n",
               skipped, ASSETS_TXT);
    }
    return (int)assetTotal;
}
