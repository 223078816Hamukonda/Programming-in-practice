# MFMS – Municipal Financial Management System (Week 11)

PAP521S Programming in Practice. Week 9–10 multi-file project with file saving,
extended in Week 11 with **structures**: Employee, Supplier, Asset, Budget and
Project records captured, stored in arrays and displayed.

## Records (`records.h`)

`Date`, `Employee`, `Supplier`, `Asset` (nested `Date acquired`), `Budget`,
`Project` (nested `Date startDate`, `Date endDate`), exactly as in the starter
code, with an include guard and `MAX_RECORDS` (100).

## Modules

| File | Responsibility |
|------|----------------|
| `main.c` | Menu and application flow only |
| `records.h` | The five structures + `Date` |
| `employees.c/.h` | `employees[]` + counter, `addEmployee`, `displayEmployees`, search, payroll, text **and binary** (`fwrite`/`fread`) save/load |
| `suppliers.c/.h` | `addSupplier`, `displaySuppliers`, text save/load |
| `assets.c/.h` | `addAsset` (asks acquired day/month/year), `displayAssets`, text save/load |
| `budget.c/.h` | `addBudget`, `displayBudgets` (shows balance = allocated − spent), text save/load |
| `projects.c/.h` | `addProject` (start and end date), `displayProjects`, text save/load |
| `dates.c/.h` | `readDate`, `isValidDate` (leap years), `compareDates` |
| `utilities.c/.h` | Input helpers and safe file helpers |
| `reports.c/.h` | Reports and report export, built on the modules' public getters |
| `config.h` | Shared constants (file paths, buffer size) |

Each module owns its array and counter as `static` variables (for example
`employees[]` / `employeeTotal` in `employees.c`) and exposes read-only getters.
This keeps the Week 9 modular design instead of putting every array in `main`.

Every `add...()` refuses a record when its array is full, rejects duplicate IDs
(Budget uses the department name as its key), and re-asks for impossible dates.
A project's end date cannot be before its start date.

## Build and run

```
make           # compiles each .c with -c, then links
./mfms
```

or `./build.sh`. Single-command form:

```
gcc -std=c99 -Wall -Wextra -pedantic main.c employees.c suppliers.c assets.c budget.c projects.c dates.c utilities.c reports.c -o mfms
```

## Menu

`1–3` employees (add, display, search) · `4–5` suppliers · `6–7` assets ·
`8–9` budgets · `10–11` projects · `12` reports · `13` export report ·
`14` save all (text) · `15` load all (text) · `16` save employees (binary) ·
`17` load employees (binary) · `18` backup · `0` exit.

## Data files (`data/`, pipe-separated text)

| File | Format |
|------|--------|
| `employees.txt` | `id\|name\|department\|salary` |
| `suppliers.txt` | `id\|name\|email\|phone\|town` |
| `assets.txt` | `id\|description\|value\|day\|month\|year` |
| `budgets.txt` | `department\|allocated\|spent` |
| `projects.txt` | `id\|title\|budget\|sday\|smonth\|syear\|eday\|emonth\|eyear` |
| `employees.dat` | raw `Employee` structs (`fwrite`/`fread`) |

Saves write to `<file>.tmp` and rename on success, so a failed save never
destroys old data. Loading skips malformed lines, duplicates, negative values
and invalid dates, and reports how many were skipped.

## Tests

`sh tests/run_tests.sh` (transcripts in `tests/output1-3.txt`):

1. Three records of every type, a duplicate ID, a duplicate budget, an impossible date (31 Feb) and an end-before-start project rejected; display every table; save text + binary; export.
2. New process: load everything back and display it; backup.
3. Binary load; missing file; garbage/duplicate/negative/incomplete lines; invalid project date.
4. 100 employees fill the array; the 101st is refused.
5. Missing `data/` directory: saves fail with a clear message, no crash.
