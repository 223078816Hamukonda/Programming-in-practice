/* dates.c */
#include <stdio.h>
#include "config.h"
#include "dates.h"
#include "utilities.h"

int isValidDate(const Date *d)
{
    static const int days[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    int max;

    if (d->year < 1900 || d->year > 2100 || d->month < 1 || d->month > 12) {
        return 0;
    }
    max = days[d->month - 1];
    if (d->month == 2 &&
        ((d->year % 4 == 0 && d->year % 100 != 0) || d->year % 400 == 0)) {
        max = 29;
    }
    return d->day >= 1 && d->day <= max;
}

int compareDates(const Date *a, const Date *b)
{
    if (a->year != b->year) {
        return a->year - b->year;
    }
    if (a->month != b->month) {
        return a->month - b->month;
    }
    return a->day - b->day;
}

void readDate(const char *label, Date *d)
{
    char prompt[LINE_LEN];

    for (;;) {
        snprintf(prompt, sizeof prompt, "  %s - day (1-31): ", label);
        d->day = readInt(prompt, 1, 31);
        snprintf(prompt, sizeof prompt, "  %s - month (1-12): ", label);
        d->month = readInt(prompt, 1, 12);
        snprintf(prompt, sizeof prompt, "  %s - year (1900-2100): ", label);
        d->year = readInt(prompt, 1900, 2100);
        if (isValidDate(d)) {
            return;
        }
        printf("  That date does not exist. Please enter it again.\n");
    }
}
