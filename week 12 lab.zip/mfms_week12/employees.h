/* employees.h - employee operations and storage */
#ifndef EMPLOYEES_H
#define EMPLOYEES_H

#include <stddef.h>
#include "records.h"

void   addEmployee(void);
void   displayEmployees(void);
void   searchEmployee(void);
double calculatePayrollTotal(void);

/* ---- Week 12: pointers ---- */
/* Changes the salary of the employee that e points to (uses ->). */
void      updateSalary(Employee *e, double newSalary);
/* Returns the ADDRESS of the employee with this id inside list[], or NULL. */
Employee *findEmployee(Employee list[], int n, int id);
/* Menu action: ask for an ID and a new salary, update in place, show the record. */
void      updateEmployeeSalary(void);

/* read-only access for other modules (e.g. reports) */
size_t          employeeCount(void);
const Employee *getEmployee(size_t index);

/* Persistence. Each returns the number of records saved/loaded, or -1 on error.
   Loading a missing file returns 0 and leaves memory untouched. */
int saveEmployeesText(void);
int loadEmployeesText(void);
int saveEmployeesBinary(void);
int loadEmployeesBinary(void);

#endif
