/* budget.c - array: budgets[], counter: budgetTotal.
   A Budget has no id, so the department name is its unique key. */
#include <stdio.h>
#include <string.h>
#include "budget.h"
#include "config.h"
#include "records.h"
#include "utilities.h"

static Budget budgets[MAX_RECORDS];
static size_t budgetTotal = 0;

static int findBudgetIndex(const char *department)
{
    size_t i;
    for (i = 0; i < budgetTotal; i++) {
        if (strcmp(budgets[i].department, department) == 0) {
            return (int)i;
        }
    }
    return -1;
}

size_t budgetCount(void)
{
    return budgetTotal;
}

const Budget *getBudget(size_t index)
{
    return (index < budgetTotal) ? &budgets[index] : NULL;
}

void addBudget(void)
{
    Budget b;

    if (budgetTotal >= MAX_RECORDS) {
        printf("  Budget list is full (%d). Record refused.\n", MAX_RECORDS);
        return;
    }
    memset(&b, 0, sizeof b);
    readText("  Department: ", b.department, sizeof b.department);
    if (findBudgetIndex(b.department) >= 0) {
        printf("  A budget for \"%s\" already exists.\n", b.department);
        return;
    }
    b.allocated = readDouble("  Amount allocated: ", 0.0);
    b.spent = readDouble("  Amount spent so far: ", 0.0);
    budgets[budgetTotal] = b;
    budgetTotal++;
    printf("  Budget for %s added.\n", b.department);
}

void displayBudgets(void)
{
    size_t i;

    if (budgetTotal == 0) {
        printf("  No budgets in memory.\n");
        return;
    }
    printf("\n  %-20s %14s %14s %14s\n", "Department", "Allocated", "Spent", "Balance");
    for (i = 0; i < budgetTotal; i++) {
        printf("  %-20.20s %14.2f %14.2f %14.2f\n", budgets[i].department,
               budgets[i].allocated, budgets[i].spent,
               budgets[i].allocated - budgets[i].spent);
    }
    printf("  Budgets: %lu   Total balance: %.2f\n",
           (unsigned long)budgetTotal, calculateBudgetBalance());
}

double calculateBudgetBalance(void)
{
    double balance = 0.0;
    size_t i;
    for (i = 0; i < budgetTotal; i++) {
        balance += budgets[i].allocated - budgets[i].spent;
    }
    return balance;
}

/* One record per line:  department|allocated|spent */

int saveBudgetsText(void)
{
    char tmp[LINE_LEN];
    FILE *fp = beginSafeWrite(BUDGETS_TXT, "w", tmp, sizeof tmp);
    size_t i;

    if (fp == NULL) {
        return -1;
    }
    for (i = 0; i < budgetTotal; i++) {
        fprintf(fp, "%s|%.2f|%.2f\n", budgets[i].department,
                budgets[i].allocated, budgets[i].spent);
    }
    if (endSafeWrite(fp, tmp, BUDGETS_TXT) != 0) {
        return -1;
    }
    return (int)budgetTotal;
}

int loadBudgetsText(void)
{
    FILE *fp = fopen(BUDGETS_TXT, "r");
    char line[LINE_LEN];
    Budget b;
    int skipped = 0;

    if (fp == NULL) {
        return reportOpenFailure(BUDGETS_TXT);
    }
    budgetTotal = 0;
    while (fgets(line, sizeof line, fp) != NULL) {
        if (line[0] == '\n' || line[0] == '\r') {
            continue;
        }
        memset(&b, 0, sizeof b);
        if (sscanf(line, "%19[^|]|%lf|%lf", b.department, &b.allocated, &b.spent) != 3 ||
            b.allocated < 0.0 || b.spent < 0.0 ||
            findBudgetIndex(b.department) >= 0 || budgetTotal >= MAX_RECORDS) {
            skipped++;
            continue;
        }
        budgets[budgetTotal++] = b;
    }
    if (ferror(fp)) {
        perror(BUDGETS_TXT);
    }
    fclose(fp);
    if (skipped > 0) {
        printf("  Warning: %d malformed/duplicate line(s) skipped in %s.\n",
               skipped, BUDGETS_TXT);
    }
    return (int)budgetTotal;
}
