#!/bin/sh
# Compile each file separately, then link both programs.
set -e
FLAGS="-std=c99 -Wall -Wextra -pedantic"
for f in main employees suppliers assets budget projects dates utilities reports salary_tools pointer_demo; do
    gcc $FLAGS -c $f.c
done
gcc main.o employees.o suppliers.o assets.o budget.o projects.o dates.o utilities.o reports.o -o mfms
gcc pointer_demo.o salary_tools.o -o pointer_demo
echo "Build OK -> ./mfms and ./pointer_demo"
