#include <stdio.h>
#include <string.h>

int main(void)
{
    char name[100];
    char town[50];
    char sentence[200] = "";

    printf("Enter supplier name: ");
    fgets(name, sizeof(name), stdin);
    name[strcspn(name, "\n")] = '\0';

    printf("Enter town: ");
    fgets(town, sizeof(town), stdin);
    town[strcspn(town, "\n")] = '\0';

    strcat(sentence, name);
    strcat(sentence, " operates in ");
    strcat(sentence, town);
    strcat(sentence, ".");

    printf("\n%s\n", sentence);

    return 0;
}
