/* employees.c - array: employees[], counter: employeeTotal */
#include <stdio.h>
#include <string.h>
#include "config.h"
#include "employees.h"
#include "records.h"
#include "utilities.h"

static Employee employees[MAX_RECORDS];
static size_t   employeeTotal = 0;

static int findEmployeeIndex(int id)
{
    size_t i;
    for (i = 0; i < employeeTotal; i++) {
        if (employees[i].id == id) {
            return (int)i;
        }
    }
    return -1;
}

size_t employeeCount(void)
{
    return employeeTotal;
}

const Employee *getEmployee(size_t index)
{
    return (index < employeeTotal) ? &employees[index] : NULL;
}

void addEmployee(void)
{
    Employee e;

    if (employeeTotal >= MAX_RECORDS) {
        printf("  Employee list is full (%d). Record refused.\n", MAX_RECORDS);
        return;
    }
    memset(&e, 0, sizeof e);
    e.id = readInt("  Employee ID (1-999999): ", 1, 999999);
    if (findEmployeeIndex(e.id) >= 0) {
        printf("  An employee with ID %d already exists.\n", e.id);
        return;
    }
    readText("  Name: ", e.name, sizeof e.name);
    readText("  Department: ", e.department, sizeof e.department);
    e.salary = readDouble("  Salary: ", 0.0);
    employees[employeeTotal] = e;
    employeeTotal++;
    printf("  Employee %d added.\n", e.id);
}

static void printEmployeeRow(const Employee *e)
{
    printf("  %-6d %-29.29s %-19.19s %12.2f\n",
           e->id, e->name, e->department, e->salary);
}

void displayEmployees(void)
{
    size_t i;

    if (employeeTotal == 0) {
        printf("  No employees in memory.\n");
        return;
    }
    printf("\n  %-6s %-29s %-19s %12s\n", "ID", "Name", "Department", "Salary");
    for (i = 0; i < employeeTotal; i++) {
        printEmployeeRow(&employees[i]);
    }
    printf("  Employees: %lu\n", (unsigned long)employeeTotal);
}

void searchEmployee(void)
{
    char term[30];
    size_t i;
    int found = 0;

    readText("  Search name or department contains: ", term, sizeof term);
    for (i = 0; i < employeeTotal; i++) {
        if (containsIgnoreCase(employees[i].name, term) ||
            containsIgnoreCase(employees[i].department, term)) {
            printEmployeeRow(&employees[i]);
            found++;
        }
    }
    if (found == 0) {
        printf("  No employee matches \"%s\".\n", term);
    }
}

double calculatePayrollTotal(void)
{
    double sum = 0.0;
    size_t i;
    for (i = 0; i < employeeTotal; i++) {
        sum += employees[i].salary;
    }
    return sum;
}

/* ------------------------- text storage ------------------------- */
/* One record per line:  id|name|department|salary                    */

int saveEmployeesText(void)
{
    char tmp[LINE_LEN];
    FILE *fp = beginSafeWrite(EMPLOYEES_TXT, "w", tmp, sizeof tmp);
    size_t i;

    if (fp == NULL) {
        return -1;
    }
    for (i = 0; i < employeeTotal; i++) {
        fprintf(fp, "%d|%s|%s|%.2f\n", employees[i].id, employees[i].name,
                employees[i].department, employees[i].salary);
    }
    if (endSafeWrite(fp, tmp, EMPLOYEES_TXT) != 0) {
        return -1;
    }
    return (int)employeeTotal;
}

int loadEmployeesText(void)
{
    FILE *fp = fopen(EMPLOYEES_TXT, "r");
    char line[LINE_LEN];
    Employee e;
    int skipped = 0;

    if (fp == NULL) {
        return reportOpenFailure(EMPLOYEES_TXT);
    }
    employeeTotal = 0;
    while (fgets(line, sizeof line, fp) != NULL) {
        if (line[0] == '\n' || line[0] == '\r') {
            continue;
        }
        memset(&e, 0, sizeof e);
        /* 29 = sizeof name - 1, 19 = sizeof department - 1 */
        if (sscanf(line, "%d|%29[^|]|%19[^|]|%lf",
                   &e.id, e.name, e.department, &e.salary) != 4 ||
            e.id < 1 || e.salary < 0.0 ||
            findEmployeeIndex(e.id) >= 0 || employeeTotal >= MAX_RECORDS) {
            skipped++;
            continue;
        }
        employees[employeeTotal++] = e;
    }
    if (ferror(fp)) {
        perror(EMPLOYEES_TXT);
    }
    fclose(fp);
    if (skipped > 0) {
        printf("  Warning: %d malformed/duplicate line(s) skipped in %s.\n",
               skipped, EMPLOYEES_TXT);
    }
    return (int)employeeTotal;
}

/* ------------------------ binary storage ------------------------ */
/* Raw Employee structs written with fwrite() and read with fread().  */

int saveEmployeesBinary(void)
{
    char tmp[LINE_LEN];
    FILE *fp = beginSafeWrite(EMPLOYEES_DAT, "wb", tmp, sizeof tmp);

    if (fp == NULL) {
        return -1;
    }
    if (employeeTotal > 0 &&
        fwrite(employees, sizeof employees[0], employeeTotal, fp) != employeeTotal) {
        fprintf(stderr, "Error writing %s\n", EMPLOYEES_DAT);
        fclose(fp);
        remove(tmp);
        return -1;
    }
    if (endSafeWrite(fp, tmp, EMPLOYEES_DAT) != 0) {
        return -1;
    }
    return (int)employeeTotal;
}

int loadEmployeesBinary(void)
{
    FILE *fp = fopen(EMPLOYEES_DAT, "rb");
    Employee e;
    int skipped = 0;

    if (fp == NULL) {
        return reportOpenFailure(EMPLOYEES_DAT);
    }
    employeeTotal = 0;
    while (fread(&e, sizeof e, 1, fp) == 1) {
        e.name[sizeof e.name - 1] = '\0';   /* never trust a file to be terminated */
        e.department[sizeof e.department - 1] = '\0';
        if (e.id < 1 || findEmployeeIndex(e.id) >= 0 || employeeTotal >= MAX_RECORDS) {
            skipped++;
            continue;
        }
        employees[employeeTotal++] = e;
    }
    if (ferror(fp)) {
        perror(EMPLOYEES_DAT);
    }
    fclose(fp);
    if (skipped > 0) {
        printf("  Warning: %d invalid/duplicate record(s) skipped in %s.\n",
               skipped, EMPLOYEES_DAT);
    }
    return (int)employeeTotal;
}
