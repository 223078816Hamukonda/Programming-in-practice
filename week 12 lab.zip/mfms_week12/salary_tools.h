/* salary_tools.h - functions that work on plain arrays of salaries
   (Week 12 Parts B and C: pointers and arrays as function parameters) */
#ifndef SALARY_TOOLS_H
#define SALARY_TOOLS_H

/* Swaps the two doubles the pointers point to. */
void   swapSalaries(double *a, double *b);

/* const = these functions only READ the array. */
void   displaySalaries(const double salaries[], int n);
double findHighest(const double salaries[], int n);
double calculateAverage(const double salaries[], int n);

/* Changes the caller's array in place: each salary grows by percent %. */
void   giveRaise(double salaries[], int n, double percent);

#endif
