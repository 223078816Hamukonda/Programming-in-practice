/* assets.c */
#include <stdio.h>
#include <string.h>
#include "assets.h"
#include "config.h"
#include "utilities.h"

static Asset  assets[MAX_RECORDS];
static size_t total = 0;

static int findAssetIndex(int id)
{
    size_t i;
    for (i = 0; i < total; i++) {
        if (assets[i].id == id) {
            return (int)i;
        }
    }
    return -1;
}

size_t assetCount(void)
{
    return total;
}

const Asset *getAsset(size_t index)
{
    return (index < total) ? &assets[index] : NULL;
}

void addAsset(void)
{
    Asset a;

    if (total >= MAX_RECORDS) {
        printf("  Asset list is full (%d).\n", MAX_RECORDS);
        return;
    }
    memset(&a, 0, sizeof a);
    a.id = readInt("  Asset ID (1-999999): ", 1, 999999);
    if (findAssetIndex(a.id) >= 0) {
        printf("  An asset with ID %d already exists.\n", a.id);
        return;
    }
    readText("  Description: ", a.name, sizeof a.name);
    a.value = readDouble("  Value: ", 0.0);
    assets[total++] = a;
    printf("  Asset %d added.\n", a.id);
}

void listAssets(void)
{
    size_t i;

    if (total == 0) {
        printf("  No assets in memory.\n");
        return;
    }
    for (i = 0; i < total; i++) {
        printf("  ID: %d | Description: %s | Value: %.2f\n",
               assets[i].id, assets[i].name, assets[i].value);
    }
}

double calculateAssetTotal(void)
{
    double sum = 0.0;
    size_t i;
    for (i = 0; i < total; i++) {
        sum += assets[i].value;
    }
    return sum;
}

/* Format, one record per line:  id|description|value */

int saveAssetsText(void)
{
    char tmp[LINE_LEN];
    FILE *fp = beginSafeWrite(ASSETS_TXT, "w", tmp, sizeof tmp);
    size_t i;

    if (fp == NULL) {
        return -1;
    }
    for (i = 0; i < total; i++) {
        fprintf(fp, "%d|%s|%.2f\n", assets[i].id, assets[i].name, assets[i].value);
    }
    if (endSafeWrite(fp, tmp, ASSETS_TXT) != 0) {
        return -1;
    }
    return (int)total;
}

int loadAssetsText(void)
{
    FILE *fp = fopen(ASSETS_TXT, "r");
    char line[LINE_LEN];
    Asset a;
    int skipped = 0;

    if (fp == NULL) {
        return reportOpenFailure(ASSETS_TXT);
    }
    total = 0;
    while (fgets(line, sizeof line, fp) != NULL) {
        if (line[0] == '\n' || line[0] == '\r') {
            continue;
        }
        memset(&a, 0, sizeof a);
        if (sscanf(line, "%d|%49[^|]|%lf", &a.id, a.name, &a.value) != 3 ||
            a.id < 1 || a.value < 0.0 ||
            findAssetIndex(a.id) >= 0 || total >= MAX_RECORDS) {
            skipped++;
            continue;
        }
        assets[total++] = a;
    }
    if (ferror(fp)) {
        perror(ASSETS_TXT);
    }
    fclose(fp);
    if (skipped > 0) {
        printf("  Warning: %d malformed/duplicate line(s) skipped in %s.\n",
               skipped, ASSETS_TXT);
    }
    return (int)total;
}
