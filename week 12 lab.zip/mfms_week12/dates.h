/* dates.h - helpers for the nested Date structure */
#ifndef DATES_H
#define DATES_H

#include "records.h"

int  isValidDate(const Date *d);                 /* 1 if the date really exists */
int  compareDates(const Date *a, const Date *b); /* <0, 0, >0 like strcmp       */
void readDate(const char *label, Date *d);       /* asks day, month, year until valid */

#endif
