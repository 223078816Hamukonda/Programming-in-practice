/* suppliers.c */
#include <stdio.h>
#include <string.h>
#include "config.h"
#include "suppliers.h"
#include "utilities.h"

static Supplier suppliers[MAX_RECORDS];
static size_t   total = 0;

static int findSupplierIndex(int id)
{
    size_t i;
    for (i = 0; i < total; i++) {
        if (suppliers[i].id == id) {
            return (int)i;
        }
    }
    return -1;
}

size_t supplierCount(void)
{
    return total;
}

const Supplier *getSupplier(size_t index)
{
    return (index < total) ? &suppliers[index] : NULL;
}

void addSupplier(void)
{
    Supplier s;

    if (total >= MAX_RECORDS) {
        printf("  Supplier list is full (%d).\n", MAX_RECORDS);
        return;
    }
    memset(&s, 0, sizeof s);
    s.id = readInt("  Supplier ID (1-999999): ", 1, 999999);
    if (findSupplierIndex(s.id) >= 0) {
        printf("  A supplier with ID %d already exists.\n", s.id);
        return;
    }
    readText("  Name: ", s.name, sizeof s.name);
    readText("  Phone: ", s.phone, sizeof s.phone);
    suppliers[total++] = s;
    printf("  Supplier %d added.\n", s.id);
}

void listSuppliers(void)
{
    size_t i;

    if (total == 0) {
        printf("  No suppliers in memory.\n");
        return;
    }
    for (i = 0; i < total; i++) {
        printf("  ID: %d | Name: %s | Phone: %s\n",
               suppliers[i].id, suppliers[i].name, suppliers[i].phone);
    }
}

/* Format, one record per line:  id|name|phone */

int saveSuppliersText(void)
{
    char tmp[LINE_LEN];
    FILE *fp = beginSafeWrite(SUPPLIERS_TXT, "w", tmp, sizeof tmp);
    size_t i;

    if (fp == NULL) {
        return -1;
    }
    for (i = 0; i < total; i++) {
        fprintf(fp, "%d|%s|%s\n",
                suppliers[i].id, suppliers[i].name, suppliers[i].phone);
    }
    if (endSafeWrite(fp, tmp, SUPPLIERS_TXT) != 0) {
        return -1;
    }
    return (int)total;
}

int loadSuppliersText(void)
{
    FILE *fp = fopen(SUPPLIERS_TXT, "r");
    char line[LINE_LEN];
    Supplier s;
    int skipped = 0;

    if (fp == NULL) {
        return reportOpenFailure(SUPPLIERS_TXT);
    }
    total = 0;
    while (fgets(line, sizeof line, fp) != NULL) {
        if (line[0] == '\n' || line[0] == '\r') {
            continue;
        }
        memset(&s, 0, sizeof s);
        /* 49 = NAME_LEN - 1, 19 = PHONE_LEN - 1 */
        if (sscanf(line, "%d|%49[^|]|%19[^|\r\n]", &s.id, s.name, s.phone) != 3 ||
            s.id < 1 || findSupplierIndex(s.id) >= 0 || total >= MAX_RECORDS) {
            skipped++;
            continue;
        }
        suppliers[total++] = s;
    }
    if (ferror(fp)) {
        perror(SUPPLIERS_TXT);
    }
    fclose(fp);
    if (skipped > 0) {
        printf("  Warning: %d malformed/duplicate line(s) skipped in %s.\n",
               skipped, SUPPLIERS_TXT);
    }
    return (int)total;
}
