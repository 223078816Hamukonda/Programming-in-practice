/* projects.c - array: projects[], counter: projectTotal */
#include <stdio.h>
#include <string.h>
#include "config.h"
#include "dates.h"
#include "projects.h"
#include "records.h"
#include "utilities.h"

static Project projects[MAX_RECORDS];
static size_t  projectTotal = 0;

static int findProjectIndex(int id)
{
    size_t i;
    for (i = 0; i < projectTotal; i++) {
        if (projects[i].id == id) {
            return (int)i;
        }
    }
    return -1;
}

size_t projectCount(void)
{
    return projectTotal;
}

const Project *getProject(size_t index)
{
    return (index < projectTotal) ? &projects[index] : NULL;
}

void addProject(void)
{
    Project p;

    if (projectTotal >= MAX_RECORDS) {
        printf("  Project list is full (%d). Record refused.\n", MAX_RECORDS);
        return;
    }
    memset(&p, 0, sizeof p);
    p.id = readInt("  Project ID (1-999999): ", 1, 999999);
    if (findProjectIndex(p.id) >= 0) {
        printf("  A project with ID %d already exists.\n", p.id);
        return;
    }
    readText("  Title: ", p.title, sizeof p.title);
    p.budget = readDouble("  Budget: ", 0.0);
    readDate("Start date", &p.startDate);
    for (;;) {
        readDate("End date", &p.endDate);
        if (compareDates(&p.endDate, &p.startDate) >= 0) {
            break;
        }
        printf("  The end date cannot be before the start date.\n");
    }
    projects[projectTotal] = p;
    projectTotal++;
    printf("  Project %d added.\n", p.id);
}

void displayProjects(void)
{
    size_t i;

    if (projectTotal == 0) {
        printf("  No projects in memory.\n");
        return;
    }
    printf("\n  %-6s %-30s %14s  %-10s  %-10s\n",
           "ID", "Title", "Budget", "Start", "End");
    for (i = 0; i < projectTotal; i++) {
        printf("  %-6d %-30.30s %14.2f  %02d/%02d/%04d  %02d/%02d/%04d\n",
               projects[i].id, projects[i].title, projects[i].budget,
               projects[i].startDate.day, projects[i].startDate.month,
               projects[i].startDate.year, projects[i].endDate.day,
               projects[i].endDate.month, projects[i].endDate.year);
    }
    printf("  Projects: %lu   Total budget: %.2f\n",
           (unsigned long)projectTotal, calculateProjectBudgetTotal());
}

double calculateProjectBudgetTotal(void)
{
    double sum = 0.0;
    size_t i;
    for (i = 0; i < projectTotal; i++) {
        sum += projects[i].budget;
    }
    return sum;
}

/* One record per line:  id|title|budget|sday|smonth|syear|eday|emonth|eyear */

int saveProjectsText(void)
{
    char tmp[LINE_LEN];
    FILE *fp = beginSafeWrite(PROJECTS_TXT, "w", tmp, sizeof tmp);
    size_t i;

    if (fp == NULL) {
        return -1;
    }
    for (i = 0; i < projectTotal; i++) {
        fprintf(fp, "%d|%s|%.2f|%d|%d|%d|%d|%d|%d\n",
                projects[i].id, projects[i].title, projects[i].budget,
                projects[i].startDate.day, projects[i].startDate.month,
                projects[i].startDate.year, projects[i].endDate.day,
                projects[i].endDate.month, projects[i].endDate.year);
    }
    if (endSafeWrite(fp, tmp, PROJECTS_TXT) != 0) {
        return -1;
    }
    return (int)projectTotal;
}

int loadProjectsText(void)
{
    FILE *fp = fopen(PROJECTS_TXT, "r");
    char line[LINE_LEN];
    Project p;
    int skipped = 0;

    if (fp == NULL) {
        return reportOpenFailure(PROJECTS_TXT);
    }
    projectTotal = 0;
    while (fgets(line, sizeof line, fp) != NULL) {
        if (line[0] == '\n' || line[0] == '\r') {
            continue;
        }
        memset(&p, 0, sizeof p);
        if (sscanf(line, "%d|%39[^|]|%lf|%d|%d|%d|%d|%d|%d", &p.id, p.title, &p.budget,
                   &p.startDate.day, &p.startDate.month, &p.startDate.year,
                   &p.endDate.day, &p.endDate.month, &p.endDate.year) != 9 ||
            p.id < 1 || p.budget < 0.0 ||
            !isValidDate(&p.startDate) || !isValidDate(&p.endDate) ||
            compareDates(&p.endDate, &p.startDate) < 0 ||
            findProjectIndex(p.id) >= 0 || projectTotal >= MAX_RECORDS) {
            skipped++;
            continue;
        }
        projects[projectTotal++] = p;
    }
    if (ferror(fp)) {
        perror(PROJECTS_TXT);
    }
    fclose(fp);
    if (skipped > 0) {
        printf("  Warning: %d malformed/duplicate line(s) skipped in %s.\n",
               skipped, PROJECTS_TXT);
    }
    return (int)projectTotal;
}
