/* assets.h - municipal asset operations and storage */
#ifndef ASSETS_H
#define ASSETS_H

#include <stddef.h>
#include "config.h"

typedef struct {
    int    id;
    char   name[NAME_LEN];
    double value;
} Asset;

void   addAsset(void);
void   listAssets(void);
double calculateAssetTotal(void);

size_t       assetCount(void);
const Asset *getAsset(size_t index);

int saveAssetsText(void);
int loadAssetsText(void);

#endif
