/* employees.h - employee operations and storage */
#ifndef EMPLOYEES_H
#define EMPLOYEES_H

#include <stddef.h>
#include "records.h"

void   addEmployee(void);
void   displayEmployees(void);
void   searchEmployee(void);
double calculatePayrollTotal(void);

/* read-only access for other modules (e.g. reports) */
size_t          employeeCount(void);
const Employee *getEmployee(size_t index);

/* Persistence. Each returns the number of records saved/loaded, or -1 on error.
   Loading a missing file returns 0 and leaves memory untouched. */
int saveEmployeesText(void);
int loadEmployeesText(void);
int saveEmployeesBinary(void);
int loadEmployeesBinary(void);

#endif
