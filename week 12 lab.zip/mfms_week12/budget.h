/* budget.h - budget operations and storage */
#ifndef BUDGET_H
#define BUDGET_H

#include <stddef.h>
#include "records.h"

void   addBudget(void);
void   displayBudgets(void);
double calculateBudgetBalance(void);   /* total allocated minus total spent */

size_t        budgetCount(void);
const Budget *getBudget(size_t index);

int saveBudgetsText(void);
int loadBudgetsText(void);

#endif
