/* budget.c */
#include <stdio.h>
#include <string.h>
#include "budget.h"
#include "config.h"
#include "utilities.h"

static Budget budgets[MAX_RECORDS];
static size_t total = 0;

static int findBudgetIndex(int id)
{
    size_t i;
    for (i = 0; i < total; i++) {
        if (budgets[i].id == id) {
            return (int)i;
        }
    }
    return -1;
}

size_t budgetCount(void)
{
    return total;
}

const Budget *getBudget(size_t index)
{
    return (index < total) ? &budgets[index] : NULL;
}

void addBudget(void)
{
    Budget b;

    if (total >= MAX_RECORDS) {
        printf("  Budget list is full (%d).\n", MAX_RECORDS);
        return;
    }
    memset(&b, 0, sizeof b);
    b.id = readInt("  Budget ID (1-999999): ", 1, 999999);
    if (findBudgetIndex(b.id) >= 0) {
        printf("  A budget with ID %d already exists.\n", b.id);
        return;
    }
    readText("  Department: ", b.department, sizeof b.department);
    b.allocated = readDouble("  Amount allocated: ", 0.0);
    b.spent = readDouble("  Amount spent so far: ", 0.0);
    budgets[total++] = b;
    printf("  Budget %d added.\n", b.id);
}

void listBudgets(void)
{
    size_t i;

    if (total == 0) {
        printf("  No budgets in memory.\n");
        return;
    }
    for (i = 0; i < total; i++) {
        printf("  ID: %d | Dept: %s | Allocated: %.2f | Spent: %.2f\n",
               budgets[i].id, budgets[i].department,
               budgets[i].allocated, budgets[i].spent);
    }
}

double calculateBudgetBalance(void)
{
    double balance = 0.0;
    size_t i;
    for (i = 0; i < total; i++) {
        balance += budgets[i].allocated - budgets[i].spent;
    }
    return balance;
}

/* Format, one record per line:  id|department|allocated|spent */

int saveBudgetsText(void)
{
    char tmp[LINE_LEN];
    FILE *fp = beginSafeWrite(BUDGETS_TXT, "w", tmp, sizeof tmp);
    size_t i;

    if (fp == NULL) {
        return -1;
    }
    for (i = 0; i < total; i++) {
        fprintf(fp, "%d|%s|%.2f|%.2f\n", budgets[i].id, budgets[i].department,
                budgets[i].allocated, budgets[i].spent);
    }
    if (endSafeWrite(fp, tmp, BUDGETS_TXT) != 0) {
        return -1;
    }
    return (int)total;
}

int loadBudgetsText(void)
{
    FILE *fp = fopen(BUDGETS_TXT, "r");
    char line[LINE_LEN];
    Budget b;
    int skipped = 0;

    if (fp == NULL) {
        return reportOpenFailure(BUDGETS_TXT);
    }
    total = 0;
    while (fgets(line, sizeof line, fp) != NULL) {
        if (line[0] == '\n' || line[0] == '\r') {
            continue;
        }
        memset(&b, 0, sizeof b);
        if (sscanf(line, "%d|%49[^|]|%lf|%lf",
                   &b.id, b.department, &b.allocated, &b.spent) != 4 ||
            b.id < 1 || b.allocated < 0.0 || b.spent < 0.0 ||
            findBudgetIndex(b.id) >= 0 || total >= MAX_RECORDS) {
            skipped++;
            continue;
        }
        budgets[total++] = b;
    }
    if (ferror(fp)) {
        perror(BUDGETS_TXT);
    }
    fclose(fp);
    if (skipped > 0) {
        printf("  Warning: %d malformed/duplicate line(s) skipped in %s.\n",
               skipped, BUDGETS_TXT);
    }
    return (int)total;
}
