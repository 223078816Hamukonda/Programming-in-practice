/* main.c - coordinates the application; the features live in the modules */
#include <stdio.h>
#include "assets.h"
#include "budget.h"
#include "config.h"
#include "employees.h"
#include "projects.h"
#include "reports.h"
#include "suppliers.h"
#include "utilities.h"

static void displayMainMenu(void)
{
    printf("\n===== Municipal Financial Management System =====\n");
    printf("  1. Add employee          2. Display employees    3. Search employees\n");
    printf("  4. Add supplier          5. Display suppliers\n");
    printf("  6. Add asset             7. Display assets\n");
    printf("  8. Add budget            9. Display budgets\n");
    printf(" 10. Add project          11. Display projects\n");
    printf(" 12. Show reports         13. Export report to file\n");
    printf(" 14. Save data (text)     15. Load data (text)\n");
    printf(" 16. Save employees (binary)   17. Load employees (binary)\n");
    printf(" 18. Backup data         19. Update employee salary\n");
    printf("  0. Exit\n");
}

static int anyNegative(const int *counts, size_t n)
{
    size_t i;
    for (i = 0; i < n; i++) {
        if (counts[i] < 0) {
            return 1;
        }
    }
    return 0;
}

static void saveAllText(void)
{
    int c[5];

    c[0] = saveEmployeesText();
    c[1] = saveSuppliersText();
    c[2] = saveAssetsText();
    c[3] = saveBudgetsText();
    c[4] = saveProjectsText();
    printf("  Saved: %d employees, %d suppliers, %d assets, %d budgets, %d projects\n",
           c[0], c[1], c[2], c[3], c[4]);
    if (anyNegative(c, 5)) {
        printf("  A negative number means that file FAILED to save.\n");
    }
}

static void loadAllText(void)
{
    int c[5];

    c[0] = loadEmployeesText();
    c[1] = loadSuppliersText();
    c[2] = loadAssetsText();
    c[3] = loadBudgetsText();
    c[4] = loadProjectsText();
    printf("  Loaded: %d employees, %d suppliers, %d assets, %d budgets, %d projects\n",
           c[0], c[1], c[2], c[3], c[4]);
    if (anyNegative(c, 5)) {
        printf("  A negative number means that file FAILED to load.\n");
    }
}

static void backupData(void)
{
    static const char *files[] = {
        EMPLOYEES_TXT, SUPPLIERS_TXT, ASSETS_TXT, BUDGETS_TXT, PROJECTS_TXT,
        EMPLOYEES_DAT
    };
    char dst[LINE_LEN];
    size_t i;
    int copied = 0;

    for (i = 0; i < sizeof files / sizeof files[0]; i++) {
        int r;
        snprintf(dst, sizeof dst, "%s.bak", files[i]);
        r = copyFile(files[i], dst);
        if (r == 0) {
            copied++;
        } else if (r == 1) {
            printf("  Skipped %s (does not exist yet).\n", files[i]);
        } else {
            printf("  FAILED to back up %s.\n", files[i]);
        }
    }
    printf("  Backup complete: %d file(s) copied to *.bak\n", copied);
}

static void reportResult(const char *what, int count)
{
    if (count >= 0) {
        printf("  %s: %d record(s).\n", what, count);
    }
}

int main(void)
{
    int choice;

    printf("Municipal Financial Management System\n");

    do {
        displayMainMenu();
        choice = readInt("Choice: ", 0, 19);

        switch (choice) {
        case 1:  addEmployee();         break;
        case 2:  displayEmployees();    break;
        case 3:  searchEmployee();      break;
        case 4:  addSupplier();         break;
        case 5:  displaySuppliers();    break;
        case 6:  addAsset();            break;
        case 7:  displayAssets();       break;
        case 8:  addBudget();           break;
        case 9:  displayBudgets();      break;
        case 10: addProject();          break;
        case 11: displayProjects();     break;
        case 12: summaryReport(stdout); break;
        case 13:
            if (exportReport() == 0) {
                printf("  Report exported to %s\n", REPORT_TXT);
            }
            break;
        case 14: saveAllText();         break;
        case 15: loadAllText();         break;
        case 16: reportResult("Binary save (employees)", saveEmployeesBinary()); break;
        case 17: reportResult("Binary load (employees)", loadEmployeesBinary()); break;
        case 18: backupData();          break;
        case 19: updateEmployeeSalary(); break;
        case 0:  printf("Goodbye. Unsaved data will be lost.\n"); break;
        default: break;
        }
        if (choice != 0) {
            pauseScreen();
        }
    } while (choice != 0);

    return 0;
}
