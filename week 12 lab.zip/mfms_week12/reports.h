/* reports.h - reports and summaries.
   Every report writes to a FILE* so the same code prints to the screen
   (pass stdout) or exports to a file. */
#ifndef REPORTS_H
#define REPORTS_H

#include <stdio.h>

void employeeReport(FILE *out);
void supplierReport(FILE *out);
void assetReport(FILE *out);
void budgetReport(FILE *out);
void projectReport(FILE *out);
void summaryReport(FILE *out);   /* all of the above */

/* Writes the summary report to data/report.txt. Returns 0 on success, -1 on error. */
int  exportReport(void);

#endif
