/* pointer_demo.c - Week 12 Parts A, B and C as one small test program.
   Build:  make pointer_demo      Run:  ./pointer_demo                    */
#include <stdio.h>
#include "salary_tools.h"

/* The "wrong" swap: parameters are COPIES, so the caller's values never change. */
static void swapSalariesWrong(double a, double b)
{
    double temp = a;
    a = b;
    b = temp;
    printf("  (inside the wrong version a=%.2f b=%.2f - swapped, but only the copies)\n",
           a, b);
}

int main(void)
{
    /* ---------- Part A: a variable and a pointer to it ---------- */
    int value = 42;
    int *p = &value;
    double first = 15000.00, second = 21000.75;
    double salaries[4] = {15000.00, 18500.50, 21000.75, 17200.00};
    int n = 4;

    printf("Part A - pointers\n");
    printf("  value  = %d\n", value);
    printf("  &value = %p\n", (void *)&value);
    printf("  p      = %p   (p holds the address of value)\n", (void *)p);
    printf("  *p     = %d   (the value p points to)\n", *p);
    *p = 99;
    printf("  after *p = 99:  value = %d, *p = %d\n", value, *p);

    /* ---------- Part B: swapping ---------- */
    printf("\nPart B - swap salaries\n");
    printf("  before:            first=%.2f second=%.2f\n", first, second);
    swapSalariesWrong(first, second);
    printf("  after WRONG swap:  first=%.2f second=%.2f   <- unchanged!\n", first, second);
    swapSalaries(&first, &second);
    printf("  after swapSalaries(&first, &second): first=%.2f second=%.2f\n", first, second);

    /* ---------- Part C: arrays and functions ---------- */
    printf("\nPart C - arrays\n");
    printf("Before raise:\n");
    displaySalaries(salaries, n);
    printf("  Highest: N$%.2f   Average: N$%.2f\n",
           findHighest(salaries, n), calculateAverage(salaries, n));

    giveRaise(salaries, n, 10.0);
    printf("\nAfter a 10%% raise (same array, changed in place):\n");
    displaySalaries(salaries, n);
    printf("  Highest: N$%.2f   Average: N$%.2f\n",
           findHighest(salaries, n), calculateAverage(salaries, n));

    printf("\nEmpty array is safe: highest=%.2f average=%.2f\n",
           findHighest(salaries, 0), calculateAverage(salaries, 0));

    return 0;
}
