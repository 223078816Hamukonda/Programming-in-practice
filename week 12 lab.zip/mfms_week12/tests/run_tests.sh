#!/bin/sh
# Run from the project folder:  sh tests/run_tests.sh
# Transcripts are saved in tests/outputN.txt
cd "$(dirname "$0")/.." || exit 1
rm -f data/*.txt data/*.dat data/*.bak data/*.tmp

echo "== Test 1: 3 records of every type, display all, save text + binary, export"
printf '%s\n' \
  1 1001 "Maria Shikongo" Finance 18500.50 "" \
  1 1002 "Simon Peters" Roads 17200 "" \
  1 1003 "Anna Amukoto" Water 21000 "" \
  1 1001 "" \
  4 501 "Windhoek Stationery" sales@wstat.na 061123456 Windhoek "" \
  4 502 "Oshakati Hardware" info@oshhard.na 065220011 Oshakati "" \
  4 503 "Swakop Fuels" fuel@swakop.na 064404040 Swakopmund "" \
  6 9001 "Fire Truck" 1250000 15 3 2021 "" \
  6 9002 "Grader" 850000 31 2 2020 28 2 2020 "" \
  6 9003 "Water Pump" 95000.50 1 7 2023 "" \
  8 Water 500000 125000.75 "" \
  8 Roads 300000 300000 "" \
  8 Finance 150000 20000 "" \
  8 Water "" \
  10 3001 "Borehole Upgrade" 750000 1 2 2026 30 11 2026 "" \
  10 3002 "Road Resurfacing" 1200000 1 6 2026 1 5 2026 15 12 2026 "" \
  10 3003 "Clinic Renovation" 400000 10 1 2026 20 8 2026 "" \
  2 "" 5 "" 7 "" 9 "" 11 "" 3 fin "" \
  14 "" 16 "" 13 "" 0 > tests/input1.txt
./mfms < tests/input1.txt > tests/output1.txt
echo "-- data files after run 1:"; ls -l data | grep -v gitkeep
echo "-- data/projects.txt:"; cat data/projects.txt

echo; echo "== Test 2: NEW process (memory empty) -> load text, display everything, backup"
printf '%s\n' 2 "" 15 "" 2 "" 5 "" 7 "" 9 "" 11 "" 18 "" 0 > tests/input2.txt
./mfms < tests/input2.txt > tests/output2.txt
grep -E "No employees|Loaded|Backup" tests/output2.txt

echo; echo "== Test 3: binary load, missing file, malformed/duplicate/invalid-date lines"
rm -f data/assets.txt
printf '%s\n' \
  '2001|Good Record|IT|100.00' \
  'this line is garbage' \
  '2001|Duplicate Id|IT|5.00' \
  '2002|Negative|IT|-5' \
  '2003|Name Only' \
  '' \
  '2004|Last Good|HR|42.50' > data/employees.txt
printf '%s\n' '3001|Bad Date|100|31|2|2026|1|3|2026' '3002|Good|100|1|3|2026|1|4|2026' > data/projects.txt
printf '%s\n' 17 "" 2 "" 15 "" 2 "" 7 "" 11 "" 0 > tests/input3.txt
./mfms < tests/input3.txt > tests/output3.txt
grep -E "Binary load|Warning|No saved|Loaded" tests/output3.txt

echo; echo "== Test 4: array full -> record refused (fill 100 employees, try a 101st)"
rm -f data/*.txt data/*.dat
{ i=1; while [ $i -le 100 ]; do printf '%s\n' 1 $i "Emp $i" Dept 1000 ""; i=$((i+1)); done
  printf '%s\n' 1 5000 "One too many" Dept 1000 "" 0; } > tests/input4.txt
./mfms < tests/input4.txt | grep -E "full|added" | sort | uniq -c | sort -rn | head -3

echo; echo "== Test 5: data directory missing -> save must fail safely"
mv data data_hidden
printf '%s\n' 1 1 Test Dept 1 "" 14 "" 0 | ./mfms 2>&1 | grep -E "data/|Saved|FAILED"
mv data_hidden data
rm -f data/*.txt data/*.dat data/*.bak data/*.tmp tests/input4.txt
