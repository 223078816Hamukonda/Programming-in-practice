#include <stdio.h>

float calculateSalary(float basic, float housing, float transport);

int main(void)
{
    float basic;
    float housing;
    float transport;
    float grossSalary;

    printf("Basic salary: ");
    scanf("%f", &basic);

    printf("Housing allowance: ");
    scanf("%f", &housing);

    printf("Transport allowance: ");
    scanf("%f", &transport);

    grossSalary = calculateSalary(basic, housing, transport);

    printf("Gross salary: %.2f\n", grossSalary);

    return 0;
}

float calculateSalary(float basic, float housing, float transport)
{
    return basic + housing + transport;
}
