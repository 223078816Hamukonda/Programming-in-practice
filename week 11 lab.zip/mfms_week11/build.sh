#!/bin/sh
# Compile each file separately, then link.
set -e
FLAGS="-std=c99 -Wall -Wextra -pedantic"
for f in main employees suppliers assets budget projects dates utilities reports; do
    gcc $FLAGS -c $f.c
done
gcc main.o employees.o suppliers.o assets.o budget.o projects.o dates.o utilities.o reports.o -o mfms
echo "Build OK -> ./mfms"
