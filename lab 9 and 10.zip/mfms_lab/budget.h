/* budget.h - budget operations and storage */
#ifndef BUDGET_H
#define BUDGET_H

#include <stddef.h>
#include "config.h"

typedef struct {
    int    id;
    char   department[NAME_LEN];
    double allocated;
    double spent;
} Budget;

void   addBudget(void);
void   listBudgets(void);
double calculateBudgetBalance(void);   /* total allocated minus total spent */

size_t        budgetCount(void);
const Budget *getBudget(size_t index);

int saveBudgetsText(void);
int loadBudgetsText(void);

#endif
