/* salary_tools.c */
#include <stdio.h>
#include "salary_tools.h"

void swapSalaries(double *a, double *b)
{
    double temp = *a;
    *a = *b;
    *b = temp;
}

void displaySalaries(const double salaries[], int n)
{
    int i;

    for (i = 0; i < n; i++) {
        printf("  Employee %d: N$%.2f\n", i + 1, salaries[i]);
    }
}

double findHighest(const double salaries[], int n)
{
    double highest;
    int i;

    if (n <= 0) {
        return 0.0;             /* nothing to compare */
    }
    highest = salaries[0];
    for (i = 1; i < n; i++) {
        if (salaries[i] > highest) {
            highest = salaries[i];
        }
    }
    return highest;
}

double calculateAverage(const double salaries[], int n)
{
    double sum = 0.0;
    int i;

    if (n <= 0) {
        return 0.0;             /* avoid dividing by zero */
    }
    for (i = 0; i < n; i++) {
        sum += salaries[i];
    }
    return sum / n;
}

void giveRaise(double salaries[], int n, double percent)
{
    int i;

    for (i = 0; i < n; i++) {
        salaries[i] += salaries[i] * percent / 100.0;
    }
}
