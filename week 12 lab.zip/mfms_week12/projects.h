/* projects.h - municipal project operations and storage */
#ifndef PROJECTS_H
#define PROJECTS_H

#include <stddef.h>
#include "records.h"

void   addProject(void);
void   displayProjects(void);
double calculateProjectBudgetTotal(void);

size_t         projectCount(void);
const Project *getProject(size_t index);

int saveProjectsText(void);
int loadProjectsText(void);

#endif
