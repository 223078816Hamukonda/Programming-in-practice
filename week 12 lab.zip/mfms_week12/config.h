/* config.h - shared application constants (MAX_RECORDS lives in records.h) */
#ifndef CONFIG_H
#define CONFIG_H

#define LINE_LEN 256   /* size of line / path buffers */

/* All data files live in the data/ directory next to the executable. */
#define DATA_DIR       "data"
#define EMPLOYEES_TXT  DATA_DIR "/employees.txt"
#define EMPLOYEES_DAT  DATA_DIR "/employees.dat"
#define SUPPLIERS_TXT  DATA_DIR "/suppliers.txt"
#define ASSETS_TXT     DATA_DIR "/assets.txt"
#define BUDGETS_TXT    DATA_DIR "/budgets.txt"
#define PROJECTS_TXT   DATA_DIR "/projects.txt"
#define REPORT_TXT     DATA_DIR "/report.txt"

#endif
