/* main.c - coordinates the application; the features live in the modules */
#include <stdio.h>
#include "assets.h"
#include "budget.h"
#include "config.h"
#include "employees.h"
#include "reports.h"
#include "suppliers.h"
#include "utilities.h"

static void displayMainMenu(void)
{
    printf("\n===== Municipal Financial Management System =====\n");
    printf("  1. Add employee          2. List employees     3. Search employee\n");
    printf("  4. Add supplier          5. List suppliers\n");
    printf("  6. Add asset             7. List assets\n");
    printf("  8. Add budget            9. List budgets\n");
    printf(" 10. Show reports         11. Export report to file\n");
    printf(" 12. Save data (text)     13. Load data (text)\n");
    printf(" 14. Save employees (binary)   15. Load employees (binary)\n");
    printf(" 16. Backup data\n");
    printf("  0. Exit\n");
}

static void saveAllText(void)
{
    int e = saveEmployeesText();
    int s = saveSuppliersText();
    int a = saveAssetsText();
    int b = saveBudgetsText();

    printf("  Saved: %d employees, %d suppliers, %d assets, %d budgets",
           e, s, a, b);
    if (e < 0 || s < 0 || a < 0 || b < 0) {
        printf("  (a negative number means that file FAILED to save)");
    }
    printf("\n");
}

static void loadAllText(void)
{
    int e = loadEmployeesText();
    int s = loadSuppliersText();
    int a = loadAssetsText();
    int b = loadBudgetsText();

    printf("  Loaded: %d employees, %d suppliers, %d assets, %d budgets",
           e, s, a, b);
    if (e < 0 || s < 0 || a < 0 || b < 0) {
        printf("  (a negative number means that file FAILED to load)");
    }
    printf("\n");
}

static void backupData(void)
{
    static const char *files[] = {
        EMPLOYEES_TXT, SUPPLIERS_TXT, ASSETS_TXT, BUDGETS_TXT, EMPLOYEES_DAT
    };
    char dst[LINE_LEN];
    size_t i;
    int copied = 0;

    for (i = 0; i < sizeof files / sizeof files[0]; i++) {
        int r;
        snprintf(dst, sizeof dst, "%s.bak", files[i]);
        r = copyFile(files[i], dst);
        if (r == 0) {
            copied++;
        } else if (r == 1) {
            printf("  Skipped %s (does not exist yet).\n", files[i]);
        } else {
            printf("  FAILED to back up %s.\n", files[i]);
        }
    }
    printf("  Backup complete: %d file(s) copied to *.bak\n", copied);
}

static void reportResult(const char *what, int count)
{
    if (count >= 0) {
        printf("  %s: %d record(s).\n", what, count);
    }
}

int main(void)
{
    int choice;

    printf("Municipal Financial Management System\n");

    do {
        displayMainMenu();
        choice = readInt("Choice: ", 0, 16);

        switch (choice) {
        case 1:  addEmployee();       break;
        case 2:  listEmployees();     break;
        case 3:  searchEmployee();    break;
        case 4:  addSupplier();       break;
        case 5:  listSuppliers();     break;
        case 6:  addAsset();          break;
        case 7:  listAssets();        break;
        case 8:  addBudget();         break;
        case 9:  listBudgets();       break;
        case 10: summaryReport(stdout); break;
        case 11:
            if (exportReport() == 0) {
                printf("  Report exported to %s\n", REPORT_TXT);
            }
            break;
        case 12: saveAllText();       break;
        case 13: loadAllText();       break;
        case 14: reportResult("Binary save (employees)", saveEmployeesBinary()); break;
        case 15: reportResult("Binary load (employees)", loadEmployeesBinary()); break;
        case 16: backupData();        break;
        case 0:  printf("Goodbye. Unsaved data will be lost.\n"); break;
        default: break;
        }
        if (choice != 0) {
            pauseScreen();
        }
    } while (choice != 0);

    return 0;
}
