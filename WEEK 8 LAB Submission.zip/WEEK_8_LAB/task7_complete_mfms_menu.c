#include <stdio.h>

float calculateVAT(float amount);
float calculateSalary(float basic, float housing, float transport);
float calculateBudget(float revenue, float expenses);
void displayMenu(void);
int searchEmployee(int id, int ids[], int size);

int main(void)
{
    int choice;
    int employeeIDs[] = {101, 102, 103, 104, 105};
    int size = (int)(sizeof(employeeIDs) / sizeof(employeeIDs[0]));

    do
    {
        float amount;
        float basic;
        float housing;
        float transport;
        float revenue;
        float expenses;
        float result;
        int employeeID;
        int position;

        displayMenu();

        if (scanf("%d", &choice) != 1)
        {
            int ch;
            printf("Invalid input. Please enter a number.\n");

            while ((ch = getchar()) != '\n' && ch != EOF)
            {
                /* Clear invalid input. */
            }

            choice = 0;
            continue;
        }

        switch (choice)
        {
            case 1:
                printf("Enter amount: ");
                scanf("%f", &amount);

                result = calculateVAT(amount);
                printf("VAT: %.2f\n", result);
                break;

            case 2:
                printf("Basic salary: ");
                scanf("%f", &basic);

                printf("Housing allowance: ");
                scanf("%f", &housing);

                printf("Transport allowance: ");
                scanf("%f", &transport);

                result = calculateSalary(basic, housing, transport);
                printf("Gross salary: %.2f\n", result);
                break;

            case 3:
                printf("Enter revenue: ");
                scanf("%f", &revenue);

                printf("Enter expenses: ");
                scanf("%f", &expenses);

                result = calculateBudget(revenue, expenses);
                printf("Budget balance: %.2f\n", result);

                if (result > 0)
                {
                    printf("SURPLUS\n");
                }
                else if (result < 0)
                {
                    printf("DEFICIT\n");
                }
                else
                {
                    printf("BALANCED\n");
                }
                break;

            case 4:
                printf("Enter employee ID: ");
                scanf("%d", &employeeID);

                position = searchEmployee(employeeID, employeeIDs, size);

                if (position != -1)
                {
                    printf("Employee found at position %d.\n", position);
                }
                else
                {
                    printf("Employee not found.\n");
                }
                break;

            case 5:
                printf("Goodbye.\n");
                break;

            default:
                printf("Invalid choice. Please choose 1 to 5.\n");
        }

        printf("\n");

    } while (choice != 5);

    return 0;
}

void displayMenu(void)
{
    printf("==================================\n");
    printf(" MUNICIPAL FINANCIAL MANAGEMENT\n");
    printf("==================================\n");
    printf("1. Calculate VAT\n");
    printf("2. Calculate Salary\n");
    printf("3. Calculate Budget\n");
    printf("4. Search Employee\n");
    printf("5. Exit\n");
    printf("Enter choice: ");
}

float calculateVAT(float amount)
{
    return amount * 0.15f;
}

float calculateSalary(float basic, float housing, float transport)
{
    return basic + housing + transport;
}

float calculateBudget(float revenue, float expenses)
{
    return revenue - expenses;
}

int searchEmployee(int id, int ids[], int size)
{
    int i;

    for (i = 0; i < size; i++)
    {
        if (ids[i] == id)
        {
            return i;
        }
    }

    return -1;
}
