#include <stdio.h>

float calculateVAT(float amount);

int main(void)
{
    float amount;
    float vat;

    printf("Enter amount: ");
    scanf("%f", &amount);

    vat = calculateVAT(amount);

    printf("VAT: %.2f\n", vat);

    return 0;
}

float calculateVAT(float amount)
{
    return amount * 0.15f;
}
