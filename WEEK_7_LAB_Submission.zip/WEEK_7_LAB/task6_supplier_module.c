#include <stdio.h>
#include <string.h>

int main(void)
{
    char name[100] = "";
    char email[100] = "";
    char phone[20] = "";
    char town[50] = "";
    char search[100];

    int choice;
    int supplierAdded = 0;

    do
    {
        printf("\n========================================\n");
        printf(" MUNICIPAL FINANCIAL MANAGEMENT SYSTEM\n");
        printf("          SUPPLIER MANAGEMENT\n");
        printf("========================================\n");
        printf("1. Add Supplier\n");
        printf("2. Display Supplier\n");
        printf("3. Search Supplier\n");
        printf("4. Show Name Length\n");
        printf("5. Exit\n");
        printf("Enter choice: ");

        if (scanf("%d", &choice) != 1)
        {
            printf("Invalid input. Please enter a number.\n");
            int ch;
            while ((ch = getchar()) != '\n' && ch != EOF) {}
            continue;
        }

        /* Remove the newline left by scanf. */
        int ch;
        while ((ch = getchar()) != '\n' && ch != EOF) {}

        switch (choice)
        {
            case 1:
                printf("\nEnter supplier name: ");
                fgets(name, sizeof(name), stdin);
                name[strcspn(name, "\n")] = '\0';

                printf("Enter email: ");
                fgets(email, sizeof(email), stdin);
                email[strcspn(email, "\n")] = '\0';

                printf("Enter phone: ");
                fgets(phone, sizeof(phone), stdin);
                phone[strcspn(phone, "\n")] = '\0';

                printf("Enter town: ");
                fgets(town, sizeof(town), stdin);
                town[strcspn(town, "\n")] = '\0';

                supplierAdded = 1;
                printf("\nSupplier added successfully.\n");
                break;

            case 2:
                if (supplierAdded)
                {
                    printf("\n--- SUPPLIER DETAILS ---\n");
                    printf("Name : %s\n", name);
                    printf("Email: %s\n", email);
                    printf("Phone: %s\n", phone);
                    printf("Town : %s\n", town);
                }
                else
                {
                    printf("\nNo supplier has been added yet.\n");
                }
                break;

            case 3:
                if (supplierAdded)
                {
                    printf("\nEnter supplier name to search: ");
                    fgets(search, sizeof(search), stdin);
                    search[strcspn(search, "\n")] = '\0';

                    if (strcmp(search, name) == 0)
                    {
                        printf("Supplier found.\n");
                    }
                    else
                    {
                        printf("Supplier not found.\n");
                    }
                }
                else
                {
                    printf("\nAdd a supplier before searching.\n");
                }
                break;

            case 4:
                if (supplierAdded)
                {
                    printf("\nSupplier name length: %zu\n", strlen(name));
                }
                else
                {
                    printf("\nAdd a supplier first.\n");
                }
                break;

            case 5:
                printf("\nExiting Supplier Management System. Goodbye!\n");
                break;

            default:
                printf("\nInvalid choice. Please choose 1 to 5.\n");
        }

    } while (choice != 5);

    return 0;
}
