/* suppliers.h - supplier operations and storage */
#ifndef SUPPLIERS_H
#define SUPPLIERS_H

#include <stddef.h>
#include "config.h"

typedef struct {
    int  id;
    char name[NAME_LEN];
    char phone[PHONE_LEN];
} Supplier;

void addSupplier(void);
void listSuppliers(void);

size_t          supplierCount(void);
const Supplier *getSupplier(size_t index);

int saveSuppliersText(void);
int loadSuppliersText(void);

#endif
