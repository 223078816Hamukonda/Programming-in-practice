# MFMS – Municipal Financial Management System (Weeks 9 & 10)

PAP521S Programming in Practice. A modular, multi-file C99 application with
persistent text and binary storage.

## Modules

| File | Responsibility |
|------|----------------|
| `main.c` | Menu and application flow only. Includes every module header. |
| `employees.c/.h` | Add / list / search employees, payroll total, text **and** binary save/load. |
| `suppliers.c/.h` | Add / list suppliers, text save/load. |
| `assets.c/.h` | Add / list assets, asset total, text save/load. |
| `budget.c/.h` | Add / list budgets, balance calculation, text save/load. |
| `utilities.c/.h` | Input helpers (`readInt`, `readDouble`, `readText`, `pauseScreen`) and file helpers (safe write, copy, open-failure report). |
| `reports.c/.h` | Reports that read other modules through their public getters; can print to screen or export to a file. |
| `config.h` | One shared header for constants (sizes, data file paths). |

Every header has an include guard. Implementations live only in `.c` files.

## Build

```
make            # compiles each .c to a .o with -c, then links into ./mfms
make clean
```

or, exactly as in the lab notes:

```
./build.sh
```

which runs `gcc -std=c99 -Wall -Wextra -pedantic -c <file>.c` for each source
file, then `gcc main.o employees.o suppliers.o assets.o budget.o utilities.o reports.o -o mfms`.

Run from this folder (the program looks for the `data/` directory next to it):

```
./mfms
```

## Data files (`data/`)

| File | Format |
|------|--------|
| `employees.txt` | `id\|name\|salary` – one record per line |
| `suppliers.txt` | `id\|name\|phone` |
| `assets.txt` | `id\|description\|value` |
| `budgets.txt` | `id\|department\|allocated\|spent` |
| `employees.dat` | raw `Employee` structs written with `fwrite()` |
| `report.txt` | exported summary report |
| `*.bak` | created by "Backup data" |

`|` is the field separator, so the input helper refuses names containing `|`.

## File-safety measures

- Every `fopen()` is checked for `NULL`; `perror()` reports the reason.
- **Saves never use `"w"` on the real file.** Data is written to `<file>.tmp`,
  checked with `ferror()`/`fclose()`, and only then renamed over the old file,
  so a failed save leaves the previous data intact.
- A missing data file on load is reported as "no saved file yet" and is not an error.
- Text loading reads with `fgets()` then `sscanf()` (`%49[^|]` keeps names with
  spaces and is bounded to the array size). Malformed lines, duplicate IDs,
  negative values and overflow are skipped and counted in a warning.
- Binary loading forces a `'\0'` at the end of every name and rejects bad IDs.
- Return values of `fread()`, `fwrite()` and `fscanf`-family calls are checked.
- Every save/load reports how many records were processed.

## Text vs binary (employees)

For the 2 test records: `employees.txt` = 56 bytes, readable in any editor;
`employees.dat` = 128 bytes (2 × 64-byte structs, including the unused part of
the 50-byte name arrays and padding), unreadable, and tied to this machine's
type sizes, padding and byte order. Text is better for exports and debugging;
binary is simple for fixed-size records but not a portable interchange format.

## Menu

`1–3` employees · `4–5` suppliers · `6–7` assets · `8–9` budgets ·
`10` show reports · `11` export report · `12` save all (text) · `13` load all (text) ·
`14` save employees (binary) · `15` load employees (binary) · `16` backup · `0` exit.

Loading **replaces** the records in memory with the file's contents.

## Tests

`sh tests/run_tests.sh` runs four scenarios; the transcripts of the first three
are in `tests/output1.txt`, `output2.txt`, `output3.txt`:

1. Enter records (including a duplicate ID that is rejected), show reports, save text + binary, export report.
2. Start a new process (memory empty), load, list, search "simon", show budgets, backup.
3. Binary load, a missing `assets.txt`, and an `employees.txt` with garbage, duplicate, negative and incomplete lines.
4. Missing `data/` directory: save fails with a clear message and nothing crashes.

## Linker-error experiment

```
rm reports.o
gcc main.o employees.o suppliers.o assets.o budget.o utilities.o -o mfms
```

`main.c` calls `summaryReport()`/`exportReport()`. The compiler accepted that
because `reports.h` declares them, but the definitions are in `reports.o`.
Without it the linker cannot resolve the symbols: `undefined reference to ...`.

## Module dependencies

```
main.c      -> assets.h budget.h config.h employees.h reports.h suppliers.h utilities.h
reports.c   -> assets.h budget.h config.h employees.h reports.h suppliers.h utilities.h
employees.c -> config.h employees.h utilities.h
suppliers.c -> config.h suppliers.h utilities.h
assets.c    -> config.h assets.h utilities.h
budget.c    -> config.h budget.h utilities.h
utilities.c -> config.h utilities.h
(every header that needs sizes includes config.h)
```

## Limits

Records are held in fixed arrays of `MAX_RECORDS` (100); dynamic memory is a
later topic. Employee/supplier/asset/budget use `typedef struct` as a preview of Week 11.
