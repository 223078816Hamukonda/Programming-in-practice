/* suppliers.h - supplier operations and storage */
#ifndef SUPPLIERS_H
#define SUPPLIERS_H

#include <stddef.h>
#include "records.h"

void addSupplier(void);
void displaySuppliers(void);

size_t          supplierCount(void);
const Supplier *getSupplier(size_t index);

int saveSuppliersText(void);
int loadSuppliersText(void);

#endif
