/* reports.c - uses only the public interfaces of the other modules */
#include <stdio.h>
#include "assets.h"
#include "budget.h"
#include "config.h"
#include "employees.h"
#include "reports.h"
#include "suppliers.h"
#include "utilities.h"

void employeeReport(FILE *out)
{
    size_t i;
    const Employee *e;

    fprintf(out, "\n=== Employee Report ===\n");
    fprintf(out, "%-8s %-25s %12s\n", "ID", "Name", "Salary");
    for (i = 0; (e = getEmployee(i)) != NULL; i++) {
        fprintf(out, "%-8d %-25.25s %12.2f\n", e->id, e->name, e->salary);
    }
    fprintf(out, "Employees: %lu   Payroll total: %.2f\n",
            (unsigned long)employeeCount(), calculatePayrollTotal());
}

void supplierReport(FILE *out)
{
    size_t i;
    const Supplier *s;

    fprintf(out, "\n=== Supplier Report ===\n");
    fprintf(out, "%-8s %-25s %-20s\n", "ID", "Name", "Phone");
    for (i = 0; (s = getSupplier(i)) != NULL; i++) {
        fprintf(out, "%-8d %-25.25s %-20s\n", s->id, s->name, s->phone);
    }
    fprintf(out, "Suppliers: %lu\n", (unsigned long)supplierCount());
}

void assetReport(FILE *out)
{
    size_t i;
    const Asset *a;

    fprintf(out, "\n=== Asset Report ===\n");
    fprintf(out, "%-8s %-25s %14s\n", "ID", "Description", "Value");
    for (i = 0; (a = getAsset(i)) != NULL; i++) {
        fprintf(out, "%-8d %-25.25s %14.2f\n", a->id, a->name, a->value);
    }
    fprintf(out, "Assets: %lu   Total value: %.2f\n",
            (unsigned long)assetCount(), calculateAssetTotal());
}

void budgetReport(FILE *out)
{
    size_t i;
    const Budget *b;

    fprintf(out, "\n=== Budget Report ===\n");
    fprintf(out, "%-8s %-20s %14s %14s %14s\n",
            "ID", "Department", "Allocated", "Spent", "Balance");
    for (i = 0; (b = getBudget(i)) != NULL; i++) {
        fprintf(out, "%-8d %-20.20s %14.2f %14.2f %14.2f\n",
                b->id, b->department, b->allocated, b->spent,
                b->allocated - b->spent);
    }
    fprintf(out, "Budgets: %lu   Total balance: %.2f\n",
            (unsigned long)budgetCount(), calculateBudgetBalance());
}

void summaryReport(FILE *out)
{
    fprintf(out, "Municipal Financial Management System - Summary Report\n");
    employeeReport(out);
    supplierReport(out);
    assetReport(out);
    budgetReport(out);
}

int exportReport(void)
{
    char tmp[LINE_LEN];
    FILE *fp = beginSafeWrite(REPORT_TXT, "w", tmp, sizeof tmp);

    if (fp == NULL) {
        return -1;
    }
    summaryReport(fp);
    return endSafeWrite(fp, tmp, REPORT_TXT);
}
