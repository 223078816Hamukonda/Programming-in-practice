/* employees.c */
#include <stdio.h>
#include <string.h>
#include "config.h"
#include "employees.h"
#include "utilities.h"

static Employee employees[MAX_RECORDS];
static size_t   total = 0;

static int findEmployeeIndex(int id)
{
    size_t i;
    for (i = 0; i < total; i++) {
        if (employees[i].id == id) {
            return (int)i;
        }
    }
    return -1;
}

size_t employeeCount(void)
{
    return total;
}

const Employee *getEmployee(size_t index)
{
    return (index < total) ? &employees[index] : NULL;
}

void addEmployee(void)
{
    Employee e;

    if (total >= MAX_RECORDS) {
        printf("  Employee list is full (%d).\n", MAX_RECORDS);
        return;
    }
    memset(&e, 0, sizeof e);
    e.id = readInt("  Employee ID (1-999999): ", 1, 999999);
    if (findEmployeeIndex(e.id) >= 0) {
        printf("  An employee with ID %d already exists.\n", e.id);
        return;
    }
    readText("  Name: ", e.name, sizeof e.name);
    e.salary = readDouble("  Salary: ", 0.0);
    employees[total++] = e;
    printf("  Employee %d added.\n", e.id);
}

void listEmployees(void)
{
    size_t i;

    if (total == 0) {
        printf("  No employees in memory.\n");
        return;
    }
    for (i = 0; i < total; i++) {
        printf("  ID: %d | Name: %s | Salary: %.2f\n",
               employees[i].id, employees[i].name, employees[i].salary);
    }
}

void searchEmployee(void)
{
    char term[NAME_LEN];
    size_t i;
    int found = 0;

    readText("  Search name contains: ", term, sizeof term);
    for (i = 0; i < total; i++) {
        if (containsIgnoreCase(employees[i].name, term)) {
            printf("  ID: %d | Name: %s | Salary: %.2f\n",
                   employees[i].id, employees[i].name, employees[i].salary);
            found++;
        }
    }
    if (found == 0) {
        printf("  No employee matches \"%s\".\n", term);
    }
}

double calculatePayrollTotal(void)
{
    double sum = 0.0;
    size_t i;
    for (i = 0; i < total; i++) {
        sum += employees[i].salary;
    }
    return sum;
}

/* ------------------------- text storage ------------------------- */
/* Format, one record per line:  id|name|salary                       */

int saveEmployeesText(void)
{
    char tmp[LINE_LEN];
    FILE *fp = beginSafeWrite(EMPLOYEES_TXT, "w", tmp, sizeof tmp);
    size_t i;

    if (fp == NULL) {
        return -1;
    }
    for (i = 0; i < total; i++) {
        fprintf(fp, "%d|%s|%.2f\n",
                employees[i].id, employees[i].name, employees[i].salary);
    }
    if (endSafeWrite(fp, tmp, EMPLOYEES_TXT) != 0) {
        return -1;
    }
    return (int)total;
}

int loadEmployeesText(void)
{
    FILE *fp = fopen(EMPLOYEES_TXT, "r");
    char line[LINE_LEN];
    Employee e;
    int skipped = 0;

    if (fp == NULL) {
        return reportOpenFailure(EMPLOYEES_TXT);
    }
    total = 0;
    while (fgets(line, sizeof line, fp) != NULL) {
        if (line[0] == '\n' || line[0] == '\r') {
            continue;   /* blank line */
        }
        memset(&e, 0, sizeof e);
        /* 49 = NAME_LEN - 1 */
        if (sscanf(line, "%d|%49[^|]|%lf", &e.id, e.name, &e.salary) != 3 ||
            e.id < 1 || e.salary < 0.0 ||
            findEmployeeIndex(e.id) >= 0 || total >= MAX_RECORDS) {
            skipped++;
            continue;
        }
        employees[total++] = e;
    }
    if (ferror(fp)) {
        perror(EMPLOYEES_TXT);
    }
    fclose(fp);
    if (skipped > 0) {
        printf("  Warning: %d malformed/duplicate line(s) skipped in %s.\n",
               skipped, EMPLOYEES_TXT);
    }
    return (int)total;
}

/* ------------------------ binary storage ------------------------ */
/* Raw Employee structs, one after another. Not portable between
   machines with different type sizes, padding or byte order.        */

int saveEmployeesBinary(void)
{
    char tmp[LINE_LEN];
    FILE *fp = beginSafeWrite(EMPLOYEES_DAT, "wb", tmp, sizeof tmp);

    if (fp == NULL) {
        return -1;
    }
    if (total > 0 &&
        fwrite(employees, sizeof employees[0], total, fp) != total) {
        fprintf(stderr, "Error writing %s\n", EMPLOYEES_DAT);
        fclose(fp);
        remove(tmp);
        return -1;
    }
    if (endSafeWrite(fp, tmp, EMPLOYEES_DAT) != 0) {
        return -1;
    }
    return (int)total;
}

int loadEmployeesBinary(void)
{
    FILE *fp = fopen(EMPLOYEES_DAT, "rb");
    Employee e;
    int skipped = 0;

    if (fp == NULL) {
        return reportOpenFailure(EMPLOYEES_DAT);
    }
    total = 0;
    while (fread(&e, sizeof e, 1, fp) == 1) {
        e.name[NAME_LEN - 1] = '\0';   /* never trust a file to be terminated */
        if (e.id < 1 || findEmployeeIndex(e.id) >= 0 || total >= MAX_RECORDS) {
            skipped++;
            continue;
        }
        employees[total++] = e;
    }
    if (ferror(fp)) {
        perror(EMPLOYEES_DAT);
    }
    fclose(fp);
    if (skipped > 0) {
        printf("  Warning: %d invalid/duplicate record(s) skipped in %s.\n",
               skipped, EMPLOYEES_DAT);
    }
    return (int)total;
}
