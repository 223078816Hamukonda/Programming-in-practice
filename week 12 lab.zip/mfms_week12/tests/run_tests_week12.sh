#!/bin/sh
# Week 12 tests. Run from the project folder:  sh tests/run_tests_week12.sh
cd "$(dirname "$0")/.." || exit 1
rm -f data/*.txt data/*.dat data/*.bak data/*.tmp

./pointer_demo > tests/demo_output.txt
echo "== Demo output saved to tests/demo_output.txt"

echo; echo "== Test A: update salary - found, not found, updated twice, bad input, empty list"
printf '%s\n' \
  19 "" \
  1 1001 Maria Finance 18500.50 "" \
  1 1002 Simon Roads 17200.00 "" \
  1 1003 Anna Water 21000.75 "" \
  19 1002 19000 "" \
  19 9999 "" \
  19 1002 19500 "" \
  19 1003 -5 22000 "" \
  2 "" 14 "" 0 > tests/input_week12a.txt
./mfms < tests/input_week12a.txt > tests/output_week12a.txt
sed 's/^Choice: //' tests/output_week12a.txt | grep -E "No employees in memory|Updated|Sorry|at least|^  100[123] "

echo; echo "== Test B: NEW process - the updated salaries survived the save/load"
printf '%s\n' 15 "" 2 "" 0 > tests/input_week12b.txt
./mfms < tests/input_week12b.txt > tests/output_week12b.txt
sed 's/^Choice: //' tests/output_week12b.txt | grep -E "Loaded|^  100[123] "
rm -f data/*.txt data/*.dat data/*.bak data/*.tmp
