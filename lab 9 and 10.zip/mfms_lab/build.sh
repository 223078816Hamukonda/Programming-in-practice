#!/bin/sh
# The lab's build commands: compile each file separately, then link.
set -e
FLAGS="-std=c99 -Wall -Wextra -pedantic"
for f in main employees suppliers assets budget utilities reports; do
    gcc $FLAGS -c $f.c
done
gcc main.o employees.o suppliers.o assets.o budget.o utilities.o reports.o -o mfms
echo "Build OK -> ./mfms"
