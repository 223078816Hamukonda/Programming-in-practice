# MFMS – Municipal Financial Management System (Week 12)

PAP521S Programming in Practice. The Week 11 project (five record types, text
and binary storage) extended with **pointers**.

## What is new in Week 12

| Lab part | Where | What |
|----------|-------|------|
| A – warm-up | `pointer_demo.c` | `int` + pointer: prints value, address, `*p`; changes the value through `*p` |
| B – swap | `salary_tools.c`, `pointer_demo.c` | `swapSalaries(double *a, double *b)` plus a deliberately **wrong** `swapSalariesWrong(double a, double b)` that only swaps copies |
| C – arrays | `salary_tools.c` | `displaySalaries`, `findHighest`, `calculateAverage` (all `const` arrays) and `giveRaise` (changes the caller's array in place; the demo prints before and after) |
| D – records | `employees.c` | `updateSalary(Employee *e, double newSalary)` using `->`; `Employee *findEmployee(Employee list[], int n, int id)` returns the address of the match or `NULL`; `updateEmployeeSalary()` is the menu action |
| Menu | `main.c` | New option **19. Update employee salary** |

`findEmployee` returns `&list[i]`, a pointer into the real array, so
`updateSalary` edits the stored record, not a copy. Both functions are
NULL-safe, and `findHighest` / `calculateAverage` return 0.0 for an empty array.
Option 19 shows the old and new salary and the updated record, and prints a
friendly message when the ID does not exist. The change is only in memory until
you save (option 14 or 16).

## Build and run

```
make                  # builds ./mfms and ./pointer_demo (each .c compiled with -c)
./pointer_demo        # Parts A-C
./mfms                # the application
```

or `./build.sh`. Single-command form for the demo:

```
gcc -std=c99 -Wall -Wextra -pedantic pointer_demo.c salary_tools.c -o pointer_demo
```

## Tests

- `sh tests/run_tests_week12.sh` – saves `tests/demo_output.txt` and runs:
  - A: update with ID found (1002 → 19000), not found (9999), the same employee updated twice (19000 → 19500), a negative salary re-prompted, and the empty-list case.
  - B: a new process loads the saved file, proving the updated salaries persisted.
- `sh tests/run_tests.sh` – the Week 11 tests (still pass).

Everything else (modules, data files, menu options 1–18) is described in the
Week 11 notes: `records.h`, `employees`, `suppliers`, `assets`, `budget`,
`projects`, `dates`, `utilities`, `reports`, `config.h`.
