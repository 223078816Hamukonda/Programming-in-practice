/* suppliers.c - array: suppliers[], counter: supplierTotal */
#include <stdio.h>
#include <string.h>
#include "config.h"
#include "records.h"
#include "suppliers.h"
#include "utilities.h"

static Supplier suppliers[MAX_RECORDS];
static size_t   supplierTotal = 0;

static int findSupplierIndex(int id)
{
    size_t i;
    for (i = 0; i < supplierTotal; i++) {
        if (suppliers[i].id == id) {
            return (int)i;
        }
    }
    return -1;
}

size_t supplierCount(void)
{
    return supplierTotal;
}

const Supplier *getSupplier(size_t index)
{
    return (index < supplierTotal) ? &suppliers[index] : NULL;
}

void addSupplier(void)
{
    Supplier s;

    if (supplierTotal >= MAX_RECORDS) {
        printf("  Supplier list is full (%d). Record refused.\n", MAX_RECORDS);
        return;
    }
    memset(&s, 0, sizeof s);
    s.id = readInt("  Supplier ID (1-999999): ", 1, 999999);
    if (findSupplierIndex(s.id) >= 0) {
        printf("  A supplier with ID %d already exists.\n", s.id);
        return;
    }
    readText("  Name: ", s.name, sizeof s.name);
    readText("  Email: ", s.email, sizeof s.email);
    readText("  Phone: ", s.phone, sizeof s.phone);
    readText("  Town: ", s.town, sizeof s.town);
    suppliers[supplierTotal] = s;
    supplierTotal++;
    printf("  Supplier %d added.\n", s.id);
}

void displaySuppliers(void)
{
    size_t i;

    if (supplierTotal == 0) {
        printf("  No suppliers in memory.\n");
        return;
    }
    printf("\n  %-6s %-24s %-26s %-14s %-12s\n",
           "ID", "Name", "Email", "Phone", "Town");
    for (i = 0; i < supplierTotal; i++) {
        printf("  %-6d %-24.24s %-26.26s %-14.14s %-12.12s\n",
               suppliers[i].id, suppliers[i].name, suppliers[i].email,
               suppliers[i].phone, suppliers[i].town);
    }
    printf("  Suppliers: %lu\n", (unsigned long)supplierTotal);
}

/* One record per line:  id|name|email|phone|town */

int saveSuppliersText(void)
{
    char tmp[LINE_LEN];
    FILE *fp = beginSafeWrite(SUPPLIERS_TXT, "w", tmp, sizeof tmp);
    size_t i;

    if (fp == NULL) {
        return -1;
    }
    for (i = 0; i < supplierTotal; i++) {
        fprintf(fp, "%d|%s|%s|%s|%s\n", suppliers[i].id, suppliers[i].name,
                suppliers[i].email, suppliers[i].phone, suppliers[i].town);
    }
    if (endSafeWrite(fp, tmp, SUPPLIERS_TXT) != 0) {
        return -1;
    }
    return (int)supplierTotal;
}

int loadSuppliersText(void)
{
    FILE *fp = fopen(SUPPLIERS_TXT, "r");
    char line[LINE_LEN];
    Supplier s;
    int skipped = 0;

    if (fp == NULL) {
        return reportOpenFailure(SUPPLIERS_TXT);
    }
    supplierTotal = 0;
    while (fgets(line, sizeof line, fp) != NULL) {
        if (line[0] == '\n' || line[0] == '\r') {
            continue;
        }
        memset(&s, 0, sizeof s);
        /* field widths = sizeof member - 1 */
        if (sscanf(line, "%d|%39[^|]|%39[^|]|%14[^|]|%19[^|\r\n]",
                   &s.id, s.name, s.email, s.phone, s.town) != 5 ||
            s.id < 1 || findSupplierIndex(s.id) >= 0 || supplierTotal >= MAX_RECORDS) {
            skipped++;
            continue;
        }
        suppliers[supplierTotal++] = s;
    }
    if (ferror(fp)) {
        perror(SUPPLIERS_TXT);
    }
    fclose(fp);
    if (skipped > 0) {
        printf("  Warning: %d malformed/duplicate line(s) skipped in %s.\n",
               skipped, SUPPLIERS_TXT);
    }
    return (int)supplierTotal;
}
